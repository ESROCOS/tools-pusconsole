/* User code: This file will not be overwritten by TASTE. */

#include <stdio.h>
#include "interface.h"

void interface_startup()
{
    /* Write your initialization code here,
       but do not make any call to a required interface. */
}

void interface_PI_tc_aux(const asn1SccPusPacket *IN_packet)
{
    /* Write your code here! */
    printf("Paquete enviado a la interfaz\n");
    interface_RI_tc(IN_packet);
    
}

