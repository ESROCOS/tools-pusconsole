/* User code: This file will not be overwritten by TASTE. */
#include "function1.h"
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <Python.h>

void *myThreadFun(void* arg)
{
                printf("Hello from thread!\n"); 
                while(1)
                {
                sleep(1);
                Py_SetProgramName("taste_main");  
                Py_Initialize();
                PyRun_SimpleString("from time import time,ctime\n"
                                                                              "print ('Today is',ctime(time()))\n");
                Py_Finalize();
                }              
}

void function1_startup()
{
    /* Write your initialization code here,
       but do not make any call to a required interface. */
       
    //init thread
    pthread_t tid;
    pthread_create(&tid, NULL, myThreadFun, NULL);
    printf("Startup completed!\n");
}

void function1_PI_trigger()
{
    /* Write your code here! */
    
    printf("Hello from trigger! \n");
}

