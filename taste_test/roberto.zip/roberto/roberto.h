/* This file was generated automatically: DO NOT MODIFY IT ! */

/* Declaration of the functions that have to be provided by the user */

#ifndef __USER_CODE_H_roberto__
#define __USER_CODE_H_roberto__

#include "C_ASN1_Types.h"

#ifdef __cplusplus
extern "C" {
#endif

void roberto_startup();

void roberto_PI_tc(const asn1SccPusPacket *);

void roberto_PI_trigger();

extern void roberto_RI_tm(const asn1SccPusPacket *);

#ifdef __cplusplus
}
#endif


#endif
